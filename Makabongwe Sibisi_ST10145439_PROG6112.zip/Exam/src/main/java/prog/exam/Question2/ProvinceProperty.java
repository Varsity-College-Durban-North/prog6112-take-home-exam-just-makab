package prog.exam.Question2;

import java.util.ArrayList;

public class ProvinceProperty 
{
    public static void main(String[] args) 
    {
        // 2D Array
        double[][] prices = new double[2][2];
        
        // Add values to 2D Array
        prices[0][0] = 800000.0;
        prices[0][1] = 1500000.0;
        prices[0][2] = 2000000.0;
        
        prices[1][0] = 700000.0;
        prices[1][1] = 1200000.0;
        prices[1][2] = 1600000.0;
        
        prices[2][0] = 750000.0;
        prices[2][1] = 1300000.0;
        prices[2][2] = 1800000.0;
        
        // Display
        String s = "----------------------------------------------------------------" +
                "\n\t Flat\t" + "\tTown House\t" + "House\n" +
                "----------------------------------------------------------------" +
                "\nGauteng: R " + prices[0][0] + "\tR " + prices[0][0] + "\tR " + prices[0][0] + "\t" +
                "\nNatal:\t R " + prices[0][0] + "\tR " + prices[0][0] + "\tR " + prices[0][0] + "\t" +
                "\nCape:\t R " + prices[0][0] + "\tR " + prices[0][0] + "\tR " + prices[0][0] + "\t\n" +
                "\nAverage property prices in Gauteng = R " + CalculateAverage(prices[0]) +
                "\nAverage property prices in Natal = R " + CalculateAverage(prices[1]) +
                "\nAverage property prices in Cape = R " + CalculateAverage(prices[2]) +
                "\n----------------------------------------------------------------";
        
        System.out.println(s);
    }
    
    // Calculates the average price of the property
    public static double CalculateAverage(double[] prices)
    {
        double avg;
        
        double total = 0.00;
        for (Double price : prices) 
        {
            total = total + price;
        }
        
        avg = total / prices.length;
        
        // Rounded off to 2 Decimal Places
        avg = Math.round(avg * 100.0) / 100.0;
        return avg;
    }
}
